from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LabelReply(_message.Message):
    __slots__ = ["results"]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[LabelResult]
    def __init__(self, results: _Optional[_Iterable[_Union[LabelResult, _Mapping]]] = ...) -> None: ...

class LabelRequest(_message.Message):
    __slots__ = ["base64_img"]
    BASE64_IMG_FIELD_NUMBER: _ClassVar[int]
    base64_img: str
    def __init__(self, base64_img: _Optional[str] = ...) -> None: ...

class LabelResult(_message.Message):
    __slots__ = ["confidence", "label"]
    CONFIDENCE_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    confidence: float
    label: str
    def __init__(self, confidence: _Optional[float] = ..., label: _Optional[str] = ...) -> None: ...
